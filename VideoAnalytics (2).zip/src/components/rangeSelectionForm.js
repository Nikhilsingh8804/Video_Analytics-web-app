import React from 'react';

export default function RangeSelectionForm() {
  
    return (
        <Card bordered={false} style={{ width: '100%' }}>
        <div className="rangeSelectionForm">
          <Form
            {...layout}
            layout={'inline'}
            form={form}
            name="control-hooks"
            onFinish={onFinish}
          >
            <Form.Item
              name="Date"
              label=""
              rules={[
                {
                  required: true
                }
              ]}
            >
              <DatePicker style={{ width: '150px' }} onChange={onChange} />
            </Form.Item>
            <Form.Item
              name="StartTime"
              label=""
              rules={[
                {
                  required: true
                }
              ]}
            >
              <TimePicker
                style={{ width: '150px' }}
                placeholder="select start time"
                format={format}
              />
            </Form.Item>
            <Form.Item
              name="EndTime"
              label=""
              rules={[
                {
                  required: true
                }
              ]}
            >
              <TimePicker
                style={{ width: '150px' }}
                placeholder="select end time"
                format={format}
              />
            </Form.Item>
            <Form.Item layout={'inline'} {...tailLayout}>
              <div>
                <Button type="primary" htmlType="submit">
                  Submit
                </Button>
              </div>
            </Form.Item>
            <Form.Item layout={'inline'} {...tailLayout}>
              <div>
                <Button htmlType="button" onClick={onReset}>
                  Reset
                </Button>
              </div>
            </Form.Item>
          </Form>
        </div>
      </Card>
    )
}