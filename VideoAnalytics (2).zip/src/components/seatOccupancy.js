import React from 'react';
import SeatMap from './seatMap';
import ReactDOM from 'react-dom';
import VideoApp from './video';
import SeatData from './seatdata';


// import {TextBlock, MediaBlock, TextRow, RectShape, RoundShape} from 'react-placeholder/lib/placeholders';
export default class SeatOccupancy extends React.Component{
    render(){
    return (<>
    <div > 
    <SeatMap />
    </div>
    <div>
        <VideoApp />
    </div>
    <div className='seat-data'>
        <SeatData />
    </div>
            
        </>
    );
}
}
