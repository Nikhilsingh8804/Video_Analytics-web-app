import { Image } from 'antd';

export default function SimpleImageViewer() {
  return (
    <Image
      width={600}
      src="https://software.intel.com/content/dam/develop/external/us/en/images/webops-5999-fig-7-738261.jpg"
    />
  );
}