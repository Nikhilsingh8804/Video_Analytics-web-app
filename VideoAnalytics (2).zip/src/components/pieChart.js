import React from "react";
import ReactDOM from "react-dom";
import Chart from "react-google-charts";
 
export default class PieChart extends React.Component {
  state = {
    chartImageURI: ""
  };
  render() {
    return (
      <div >
        <Chart
         width={'600px'}
         height={'300px'}
         chartType="PieChart"
         loader={<div>Loading Chart</div>}
         data={this.props.data}
         options={{
           title: 'High Occupancy Zone',
           // Just add this option
           is3D: true,
         }}
         rootProps={{ 'data-testid': '3' }}
        />
      </div>
    );
  }
}