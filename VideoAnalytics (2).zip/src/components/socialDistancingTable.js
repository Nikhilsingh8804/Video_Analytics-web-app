import { Table } from 'antd';
import React from "react";

const columns = [
  {
    title: 'Timestamp',
    dataIndex: 'timestamp',
  },
  {
    title: 'Count Of Social Distance Violation',
    dataIndex: 'count',
  },
  {
    title: 'Snapshot',
    dataIndex: 'snapshot',
  },
];

// const data = [
//     {timestamp : '2021-08-09 10:10',
//       count: 12,
//       snapshot: './drive/snapshots/violation1.jpeg',
//     },
//     {
//         timestamp : '2021-08-09 10:25',
//         count: 18,
//         snapshot: './drive/snapshots/violation2.jpeg',
//     },
//     {
//         timestamp : '2021-08-09 10:31',
//         count: 4,
//         snapshot: './drive/snapshots/violation3.jpeg',
//     },
//     {
//         timestamp : '2021-08-09 10:44',
//         count: 2,
//         snapshot: './drive/snapshots/violation4.jpeg',
//     },
//     {
//         timestamp : '2021-08-09 10:56',
//         count: 7,
//         snapshot: './drive/snapshots/violation5.jpeg',
//     },
//   ];

export default class SocialDistancingTable extends React.Component {
  state = {
    selectedRowKeys: [], // Check here to configure the default column
  };

  onSelectChange = selectedRowKeys => {
    console.log('selectedRowKeys changed: ', selectedRowKeys);
    this.setState({ selectedRowKeys });
  };

  render() {
    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
      selections: [
        Table.SELECTION_ALL,
        Table.SELECTION_INVERT,
        Table.SELECTION_NONE,
        {
          key: 'odd',
          text: 'Select Odd Row',
          onSelect: changableRowKeys => {
            let newSelectedRowKeys = [];
            newSelectedRowKeys = changableRowKeys.filter((key, index) => {
              if (index % 2 !== 0) {
                return false;
              }
              return true;
            });
            this.setState({ selectedRowKeys: newSelectedRowKeys });
          },
        },
        {
          key: 'even',
          text: 'Select Even Row',
          onSelect: changableRowKeys => {
            let newSelectedRowKeys = [];
            newSelectedRowKeys = changableRowKeys.filter((key, index) => {
              if (index % 2 !== 0) {
                return true;
              }
              return false;
            });
            this.setState({ selectedRowKeys: newSelectedRowKeys });
          },
        },
      ],
    };
    return <Table rowSelection={rowSelection} columns={columns} dataSource={this.props.data} />;
  }
}

