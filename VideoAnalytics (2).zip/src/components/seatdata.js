import { Statistic, Card, Row, Col } from 'antd';
import { ArrowUpOutlined, ArrowDownOutlined } from '@ant-design/icons';
// import SimpleSeatData from './simpleseatdata';

export default function SeatData() {
    return(
  <div className="site-statistic-demo-card">
    <Row gutter={3}>
      <Col span={2}>
        <Card>
          <Statistic
            title="Available"
            value={17}
            // precision={2}
            valueStyle={{ color: '#008080' }}
            // prefix={<ArrowUpOutlined />}
            // suffix="%"
          />
        </Card>
      </Col>
      <Col span={2}>
        <Card>
          <Statistic
            title="Occupied"
            value={3}
            // precision={2}
            valueStyle={{ color: '#3f8600' }}
            // prefix={<ArrowDownOutlined />}
            // suffix="%"
          />
        </Card>
      </Col>
      <Col span={2}>
        <Card>
          <Statistic
            title="Total"
            value={20}
            // precision={2}
            valueStyle={{ color: '#800000' }}
            // prefix={<ArrowUpOutlined />}
            // suffix="%"
          />
        </Card>
      </Col>
    </Row>
  </div>
)};