import React from 'react';
import ReactDOM from 'react-dom';
import Chart from 'react-google-charts';

const data = [
  ['Time', 'People Count', { role: 'style' }],
  ['10:00', 35, 'color: #1890ff'],
  ['11:00', 45, 'color: #1890ff'],
  ['12:00', 50, 'color: #1890ff'],
  ['13:00', 47, 'color: #1890ff'],
];
export default class PeopleCountChart extends React.Component {
  render() {
    return (
      <div className="PeopleCount">
        <Chart options={{
    hAxis: {
      title: 'Time',
    },
    vAxis: {
      title: 'PeopleCount',
    },
  }} chartType="LineChart" width="100%" height="300px" data={this.props.data} />
      </div>
    );
  }
}
