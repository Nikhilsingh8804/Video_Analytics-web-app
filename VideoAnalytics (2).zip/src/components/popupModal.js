import { classDeclaration } from '@babel/types';
import React from 'react';

// export default class popupModal extends React.Component {
//      [isModalVisible, setIsModalVisible] = useState(false);

//     const showModal = () => {
//       setIsModalVisible(true);
//     };
  
//     const handleOk = () => {
//       setIsModalVisible(false);
//     };
  
//     const handleCancel = () => {
//       setIsModalVisible(false);
//     };
//     render() {
//       return (
//         <Modal title="Basic Modal" visible={isModalVisible} onOk={handleOk} onCancel={handleCancel}>
//         <p>Some contents...</p>
//         <p>Some contents...</p>
//         <p>Some contents...</p>
//       </Modal>
//       )
//     }

// }


import React, { useState } from 'react';
import { Modal, Button } from 'antd';

const PopupModel = () => {
  const [isModalVisible, setIsModalVisible] = useState(false);

  const showModal = () => {
    setIsModalVisible(true);
  };

  const handleOk = () => {
    setIsModalVisible(false);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };
  return (
    <>
      <Modal style={{width:'70vw',height:'60vh'}} title="Social Distance Violation" visible={isModalVisible} onOk={handleOk} onCancel={handleCancel}>
    <img style={{width:'100%',height:'100%'}} src="https://cdn.pixabay.com/photo/2021/08/07/21/00/ural-owl-6529375_960_720.jpg" />
      </Modal>
    </>
  );
};

ReactDOM.render(<PopupModel />, mountNode);