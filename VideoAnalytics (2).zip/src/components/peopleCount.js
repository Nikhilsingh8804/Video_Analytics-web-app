import React from 'react';

import { TimePicker, DatePicker } from 'antd';
import moment from 'moment';
import { Form, Input, Button, Select } from 'antd';
import { Card } from 'antd';
const { RangePicker } = DatePicker;

import PeopleCountChart from './peopleCountChart';
import InfoSection from './infoSection';

const format = 'HH:mm';

export default function PeopleCount() {
  const [showResults, setShowResults] = React.useState(false);
  const [lineChartData, setLineChartData] = React.useState([]);
  const [avgPeopleCount, setAvgPeopleCount] = React.useState(0);
  const { Option } = Select;
  const layout = {
    labelCol: {
      span: 8
    },
    wrapperCol: {
      span: 16
    }
  };

  const tailLayout = {
    wrapperCol: {
      offset: 2,
      span: 8
    }
  };
  const [form] = Form.useForm();
  function onChange(value, dateString) {
    console.log('Selected Time: ', value);
    console.log('Formatted Selected Time: ', dateString);
  }

  function formatPeopleCountData(fetchedData) {
    const data = [["Time", "People Count", { role: "style" }]];
    for (let i = 0; i < fetchedData["time"].length; i++) {
      var tempData = [];
      tempData.push(fetchedData["time"][i]);
      tempData.push(parseInt(fetchedData["people_count"][i]));
      tempData.push("color: #1890ff");
      data.push(tempData);
    }
    return data;
  }

  //POST Call
  async function fetchPeopleCount(values) {
    const response = await fetch('http://localhost:5000/people/count',
      {
        method: 'POST',
        body: JSON.stringify(values),
        headers: {
          'Content-Type': 'application/json'
        }
      }
    )
    const data = await response.json();
    console.log(data);
    setAvgPeopleCount(data['peopleCount']['avg_count']);
    const formattedData = formatPeopleCountData(data['peopleCount']);
    setLineChartData(formattedData);
    setShowResults(true);
  }

  const onFinish = values => {
    const formData = JSON.parse(JSON.stringify(values))
    const reqFormat = {
      "day": moment((formData).Date).format('DD/MM/YYYY'),
      "start_time": moment((formData).StartTime).format('HH'),
      "end_time": moment((formData).EndTime).format('HH')
    }
    fetchPeopleCount(reqFormat);
  };

  const onReset = () => {
    form.resetFields();
  };

  return (
    <div style={{ width: '100%', height: '100%' }}>
      <Card bordered={false} style={{ width: '100%' }}>
        <div className="rangeSelectionForm">
          <Form
            {...layout}
            layout={'inline'}
            form={form}
            name="control-hooks"
            onFinish={onFinish}
          >
            <Form.Item
              name="Date"
              label=""
              rules={[
                {
                  required: true
                }
              ]}
            >
              <DatePicker style={{ width: '150px' }} onChange={onChange} />
            </Form.Item>
            <Form.Item
              name="StartTime"
              label=""
              rules={[
                {
                  required: true
                }
              ]}
            >
              <TimePicker
                style={{ width: '150px' }}
                placeholder="select start time"
                format={format}
              />
            </Form.Item>
            <Form.Item
              name="EndTime"
              label=""
              rules={[
                {
                  required: true
                }
              ]}
            >
              <TimePicker
                style={{ width: '150px' }}
                // style={{ marginLeft: '10px' }}
                placeholder="select end time"
                format={format}
              />
            </Form.Item>
            <Form.Item layout={'inline'} {...tailLayout}>
              <div>
                <Button type="primary" htmlType="submit">
                  Submit
                </Button>
              </div>
            </Form.Item>
            <Form.Item layout={'inline'} {...tailLayout}>
              <div>
                <Button htmlType="button" onClick={onReset}>
                  Reset
                </Button>
              </div>
            </Form.Item>
          </Form>
        </div>
      </Card>

      {showResults ? (
        <div
          style={{
            width: '100%',
            height: '400px',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center'
          }}
        >
          <div style={{ width: '100%' }}>
            <Card
              title="Average People Count"
              bordered={true}
              style={{
                float: 'left',
                height: '350px',
                width: '35%',
                boxShadow: '5px 8px 24px 5px rgba(208, 216, 243, 0.6)'
              }}
            >
              <div
                className="centered countAraa"
                style={{
                  width: '100%',
                  height: '100%',
                  paddingBottom: '10px',
                  fontSize: '44px',
                  height: '225px',
                  color: '#1890ff',
                  letterSpacing: '0.8px'
                }}
              >
                {avgPeopleCount}
              </div>
            </Card>
            <Card
              bordered={true}
              style={{
                marginLeft: '2%',
                float: 'left',
                width: '63%',
                height: '350px',
                boxShadow: '5px 8px 24px 5px rgba(208, 216, 243, 0.6)'
              }}
            >
              <div
                style={{
                  width: '100%',
                  height: '100%',
                  paddingBottom: '30px',
                  fontSize: '32px'
                }}
              >
                <PeopleCountChart data={lineChartData} style={{ width: '100%', height: '100%' }} />
              </div>
            </Card>
          </div>
        </div>
      ) : (
        <InfoSection component={'get people count'} ></InfoSection>
      )}
    </div>
  );
}
