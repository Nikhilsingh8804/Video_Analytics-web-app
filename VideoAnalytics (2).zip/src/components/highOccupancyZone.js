import React from 'react';

import { TimePicker, DatePicker } from 'antd';
import { Form, Button } from 'antd';
import { Card } from 'antd';

import moment from 'moment';

import PieChart from './pieChart';
import ReactEcharts from 'echarts-for-react';
import InfoSection from './infoSection';

const format = 'HH:mm';

export default function HighOccupancyZone() {
  var hours = [];
  var days = [];
  var data = [];



  const [option, setOption] = React.useState({});
  const [showResults, setShowResults] = React.useState(false);
  const [pieChartData, setPieChartData] = React.useState({});

  const layout = {
    labelCol: {
      span: 8
    },
    wrapperCol: {
      span: 16
    }
  };

  const tailLayout = {
    wrapperCol: {
      offset: 2,
      span: 8
    }
  };
  const [form] = Form.useForm();

  function onChange(value, dateString) {
    console.log('Selected Time: ', value);
    console.log('Formatted Selected Time: ', dateString);
  }

  function formatHighOccypancyZoneData(apiData) {
    var resData = apiData['highOccupancyZone']['data'];
    Object.keys(resData).map(function (key, index) {
      if (key != 'timestamp') {
        days.push(key);
        for (let i = 0; i < resData[key].length; i++) {
          data.push([index, i, resData[key][i]])
        }
      } else if (key == 'timestamp') {
        hours = resData[key]
      }
    });
    data = data.map(function (item) {
      return [item[1], item[0], item[2] || '-'];
    });
    var config = {
      color: '91cc75',
      tooltip: {
        position: 'top'
      },
      grid: {
        height: '50%',
        top: '10%'
      },
      xAxis: {
        type: 'category',
        data: hours,
        splitArea: {
          show: true
        }
      },
      yAxis: {
        type: 'category',
        data: days,
        splitArea: {
          show: true
        }
      },
      visualMap: {
        min: 0,
        max: 10,
        calculable: true,
        orient: 'horizontal',
        left: 'center',
        bottom: '15%',
        inRange: {
          color: ['#c0e0fe', '#1890ff'] //From smaller to bigger value ->
        }
      },
      series: [
        {
          name: 'People Count',
          type: 'heatmap',
          data: data,
          label: {
            show: true
          },
          emphasis: {
            itemStyle: {
              shadowBlur: 10,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          }
        }
      ]
    };
    config['xAxis']['data'] = hours;
    config['yAxis']['data'] = days;
    config['series']['data'] = data;
    setOption(config);
    var totalZoneCount = apiData['highOccupancyZone']['totalCount']
    console.log(totalZoneCount);
    setPieChartData([
      ['Zone', 'Occupancy'],
      ['Kiosk', totalZoneCount['kiosk']],
      ['Departure', totalZoneCount['departure']],
      ['Check-in', totalZoneCount['checkin']]
    ])
    setShowResults(true);
  }

//POST Call
async function fetchHighOccupancyZone(values) {
  const response = await fetch('http://localhost:5000/people/zone',
    {
      method: 'POST',
      body: JSON.stringify(values),
      headers: {
        'Content-Type': 'application/json'
      }
    }
  )
  const data = await response.json();
  console.log(data);
  formatHighOccypancyZoneData(data);
}

  const onFinish = values => {
    console.log(values);
    const formData = JSON.parse(JSON.stringify(values))
    const reqFormat = {
      "day": moment((formData).Date).format('DD/MM/YYYY'),
      "start_time": moment((formData).StartTime).format('HH'),
      "end_time": moment((formData).EndTime).format('HH')
    }
    fetchHighOccupancyZone(reqFormat);
  };

  const onReset = () => {
    form.resetFields();
  };

  return (
    <div style={{ width: '100%', height: '100%' }}>
      <Card bordered={false} style={{ width: '100%' }}>
        <div className="rangeSelectionForm">
          <Form
            {...layout}
            layout={'inline'}
            form={form}
            name="control-hooks"
            onFinish={onFinish}
          >
            <Form.Item
              name="Date"
              label=""
              rules={[
                {
                  required: true
                }
              ]}
            >
              <DatePicker style={{ width: '150px' }} onChange={onChange} />
            </Form.Item>
            <Form.Item
              name="StartTime"
              label=""
              rules={[
                {
                  required: true
                }
              ]}
            >
              <TimePicker
                style={{ width: '150px' }}
                placeholder="select start time"
                format={format}
              />
            </Form.Item>
            <Form.Item
              name="EndTime"
              label=""
              rules={[
                {
                  required: true
                }
              ]}
            >
              <TimePicker
                style={{ width: '150px' }}
                placeholder="select end time"
                format={format}
              />
            </Form.Item>
            <Form.Item layout={'inline'} {...tailLayout}>
              <div>
                <Button type="primary" htmlType="submit">
                  Submit
                </Button>
              </div>
            </Form.Item>
            <Form.Item layout={'inline'} {...tailLayout}>
              <div>
                <Button htmlType="button" onClick={onReset}>
                  Reset
                </Button>
              </div>
            </Form.Item>
          </Form>
        </div>
      </Card>
      {showResults ? <div>
        <div
          style={{
            float: 'left',
            marginTop: '2%',
            width: '55%',
            boxShadow: 'rgb(208 216 243 / 60%) 5px 8px 24px 5px'
          }}
        >
          <ReactEcharts option={option} />
        </div>
        <div
          style={{
            marginLeft: '1%',
            float: 'left',
            marginTop: '2%',
            width: '40%',
            boxShadow: 'rgb(208 216 243 / 60%) 5px 8px 24px 5px'
          }}
        >
          <PieChart data={pieChartData} />
        </div>
      </div> : (
        <InfoSection component={'view High Occupancy Zone'} ></InfoSection>
      )}
    </div>
  );
}
