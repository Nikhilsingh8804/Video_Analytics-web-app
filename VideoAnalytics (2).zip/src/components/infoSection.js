import React from "react";
 
export default class InfoSection extends React.Component {
  render() {
    return (
        <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height: '350px',
          color: 'grey'
        }}
      >
        <i className="fa fa-info-circle" />
        &nbsp; please select start time and endtime to {this.props.component}
      </div>
    );
  }
}