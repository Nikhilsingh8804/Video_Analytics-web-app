import React from "react";
import "./style.css";

import 'antd/dist/antd.css'; 

import Navbar from './components/navbar';
import Login from './components/login';
import Home from './components/home'
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

export default function App() {
  
  return (<Router>
    <div>
      <Navbar></Navbar>
     <Switch>
            <Route exact path='/' component={Login} />
            <Route path="/sign-in" component={Login} />
            <Route path="/home" component={Home} />
          </Switch>
    </div></Router>
  );

}
