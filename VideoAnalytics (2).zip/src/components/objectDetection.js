import React from 'react';
import DetectionList from './objChart';
import SimpleImageViewer from './imageViewer';

export default function ObjectDetection(){
    return (<div> 
        <div className='detection-alert'> 
            <DetectionList />
        </div>
        <div className='image-viewer'>
            <SimpleImageViewer />
        </div>
        </div>
    );
}
